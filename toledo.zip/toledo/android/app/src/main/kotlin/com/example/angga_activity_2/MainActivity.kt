package com.example.angga_activity_2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
