<?php
// Database connection details
$host = "localhost";
$user = "root";          // default for XAMPP/WAMP
$pass = "";              // default password (empty in XAMPP)
$dbname = "toledo bamdb";  // <- change to your database name

// Create MySQL connection
$conn = new mysqli($host, $user, $pass, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prepare the SQL insert statement
$stmt = $conn->prepare("INSERT INTO users (name, email, age) VALUES (?, ?, ?)");
$stmt->bind_param("ssi", $name, $email, $age);

// Get form data
$name = $_POST['name'];
$email = $_POST['email'];
$age = $_POST['age'];

// Execute the insert
if ($stmt->execute()) {
    echo "Registration successful!";
} else {
    echo "Error: " . $stmt->error;
}

// Close connection
$stmt->close();
$conn->close();
?>
