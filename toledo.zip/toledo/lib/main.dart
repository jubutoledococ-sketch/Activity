<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dynamic Data Display</title>
</head>
<body>
    <h2>Random Post Viewer</h2>
    <p id="post">Waiting for data...</p>
    <button id="loadPost">Load Post</button>

    <script>
    document.getElementById("loadPost").addEventListener("click", function()
    {
        fetch('https://jsonplaceholder.typicode.com/posts/2')
        .then(response => response.json())
        .then(data => {
            document.getElementById("post").innerHTML =
                "<strong>Title:</strong> " + data.title + "<br><br>" + data.body;
        });
    });
    </script>
</body>
</html>