<!DOCTYPE html>
<html>
<head>
    <title>Simple Web Form</title>
</head>
<body>
    <h2>Registration Form</h2>

    <form action="insert.php" method="post">
        <label>Name:</label><br>
        <input type="text" name="name" required><br><br>

        <label>Email:</label><br>
        <input type="email" name="email" required><br><br>

        <label>Age:</label><br>
        <input type="number" name="age" required><br><br>

        <button type="submit">Submit</button>
    </form>

</body>
</html>